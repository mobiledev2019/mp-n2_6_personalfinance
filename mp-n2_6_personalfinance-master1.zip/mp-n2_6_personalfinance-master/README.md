# mp-n2_6_personalfinance
mp-n2_6_personalfinance created by GitHub Classroom
Các tính năng đang có:
- Thêm bản khoản thu chi
- Hiển thị lịch sử các khoản thu chi
- Tính toán các khoản thu chi hiện thị ra màn hình
- Lập biểu đồ thống kê thu chi theo ngày, tháng, năm
- Đặt hạn mức thu chi, nến vượt qua hạn mức thì gửi thông báo cho người dùng để cảnh báo
- Cho phép người dùng lưu ảnh hóa đơn lại từ bằng cách chụp ảnh trưcj tiếp hoặc lấy ảnh ra từ thư viện.
- Hiện thị lịch sử thu chi tiền sử dụng custom adapter, sắp xếp theo ngày thu chi tiền
- Thêm cơ chế tự động định dạng lại số tiền khi người dùng nhập vào edit text
- Thêm chức năng tự động kiểm tra người dùng đã thêm phiếu thu phiếu chi trong ngày chưa, nếu chưa thì gửi thông báo cho người dùng
